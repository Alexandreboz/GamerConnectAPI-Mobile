import 'package:flutter/material.dart';
import 'register_step2.dart';

class RegisterStep1 extends StatelessWidget {
  final TextEditingController nomController = TextEditingController();
  final TextEditingController prenomController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController emailConfirmController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.black, title: Text("GamerConnect")),
      backgroundColor: Color(0xFF1E1E1E),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text("CREER VOTRE COMPTE", style: TextStyle(color: Colors.white, fontSize: 20), textAlign: TextAlign.center),
            SizedBox(height: 20),
            _buildField("Nom", nomController),
            _buildField("Prenom", prenomController),
            _buildField("Adresse e-mail", emailController),
            _buildField("Confirmer votre adresse e-mail", emailConfirmController),
            SizedBox(height: 10),
            TextFormField(
              initialValue: "France",
              enabled: false,
              decoration: _fieldDecoration("Pays de résidence"),
              style: TextStyle(color: Colors.white),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Checkbox(value: true, onChanged: (_) {}, activeColor: Colors.blue),
                Text("Je suis humain", style: TextStyle(color: Colors.white)),
              ],
            ),
            SizedBox(height: 20),
            Container(
              height: 200,
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.grey[850], borderRadius: BorderRadius.circular(8)),
              child: SingleChildScrollView(
                child: Text("ACCORD DE SOUSCRIPTION STEAM

1. Inscription...
...
10. Droit applicable...",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RegisterStep2())),
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3B5AFE)),
              child: Text("Continuer"),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildField(String label, TextEditingController controller) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        style: TextStyle(color: Colors.white),
        decoration: _fieldDecoration(label),
      ),
    );
  }

  InputDecoration _fieldDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(color: Colors.grey[300]),
      filled: true,
      fillColor: Colors.grey[900],
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
    );
  }
}