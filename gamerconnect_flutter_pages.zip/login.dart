import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  final TextEditingController pseudoController = TextEditingController();
  final TextEditingController mdpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.black, title: Text("GamerConnect")),
      backgroundColor: Color(0xFF1E1E1E),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text("SE CONNECTER", style: TextStyle(color: Colors.white, fontSize: 20), textAlign: TextAlign.center),
            SizedBox(height: 20),
            _buildField("Pseudo / e-mail", pseudoController),
            _buildField("Mot de passe", mdpController, obscure: true),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3B5AFE)),
              child: Text("Se connecter"),
            ),
            SizedBox(height: 10),
            Text("J'ai besoin d'aide pour me connecter", style: TextStyle(color: Colors.grey[400]), textAlign: TextAlign.center),
            SizedBox(height: 20),
            Text("C'est gratuit et facile... En savoir plus sur Steam", style: TextStyle(color: Colors.white70), textAlign: TextAlign.center)
          ],
        ),
      ),
    );
  }

  Widget _buildField(String label, TextEditingController controller, {bool obscure = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        style: TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.grey[300]),
          filled: true,
          fillColor: Colors.grey[900],
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
    );
  }
}