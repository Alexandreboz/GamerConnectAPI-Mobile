import 'package:flutter/material.dart';
import 'screens/welcome.dart';
import 'screens/register_step1.dart';
import 'screens/register_step2.dart';
import 'screens/login.dart';

void main() {
  runApp(const GamerConnectApp());
}

class GamerConnectApp extends StatelessWidget {
  const GamerConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GamerConnect',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      initialRoute: '/',
      routes: {
        '/': (context) => WelcomePage(), // <- NE PAS mettre "const" si la classe ne l’est pas
        '/register-step1': (context) => RegisterStep1Page(),
        '/register-step2': (context) => RegisterStep2Page(),
        '/login': (context) => LoginPage(),
      },
    );
  }
}
