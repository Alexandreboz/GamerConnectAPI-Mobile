import 'package:flutter/material.dart';

class RegisterStep2 extends StatelessWidget {
  final TextEditingController pseudoController = TextEditingController();
  final TextEditingController mdpController = TextEditingController();
  final TextEditingController mdpConfirmController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.black, title: Text("GamerConnect")),
      backgroundColor: Color(0xFF1E1E1E),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text("CREER VOTRE COMPTE", style: TextStyle(color: Colors.white, fontSize: 20), textAlign: TextAlign.center),
            SizedBox(height: 20),
            _buildField("Pseudo", pseudoController),
            _buildField("Choisissez un mot de passe", mdpController, obscure: true),
            _buildField("Confirmer votre mot de passe", mdpConfirmController, obscure: true),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3B5AFE)),
              child: Text("Confirmer"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField(String label, TextEditingController controller, {bool obscure = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        style: TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.grey[300]),
          filled: true,
          fillColor: Colors.grey[900],
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
    );
  }
}